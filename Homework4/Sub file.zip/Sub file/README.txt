Question 1. 
I use the landlord to close the door and lock it.
This makes the students not able to enter the 
party.

Question 2.
When the landlord is on thier last check I force
the landlord to wait for a signal befor exiting
the "room"

Question 3. 
I make sure all threads are terminated form the 
enter/exit well the landlord is in the room on
there last check. Then I print the final 
message.