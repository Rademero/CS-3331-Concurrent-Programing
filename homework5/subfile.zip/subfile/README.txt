Question 1. 
I setup an array to hold the 3 elfs to enter the
room. the rest wait for the room to be open.

Question 2.
I set a wait signal when an elf enters the room
and santa will use a signal after the question is
answered.
ex.Santa is helping elves
     Reindeer 4 returns
     Reindeer 8 returns
     The last reindeer 3 wakes up Santa
Santa answers the question posted by elves3, 6, 7
          Elf 3, 6, 7 return to work


Question 3. 
I lock all other elfs out of the monitor when 3
elfs ask a question. 
ex. Elf 1 has a problem
          Elf 7 has a problem
          Elf 5 has a problem
          Elf 1, 7, 5 wake up the Santa
Santa is preparing sleighs
The team flies off (2)!
     Reindeer 1 returns
     Reindeer 2 returns
     Reindeer 4 returns
     Reindeer 3 returns
     Reindeer 6 returns
     Reindeer 5 returns
     Reindeer 7 returns
     Reindeer 9 returns
Santa is helping elves
     The last reindeer 8 wakes up Santa
Santa answers the question posted by elves1, 7, 5

Question 4.
I lock santa in the sleep part of a monitor and
I only send a signal when 3 elfs ask a question
or all reindeer are back.

Question 5.
I do this by setting up a counter for all of the 
reindeer who have returned.
the lastone enters a diffrent else statment and 
prints the wake statment.
ex.
 Reindeer 2 returns
     Reindeer 5 returns
     Reindeer 1 returns
     Reindeer 4 returns
     Reindeer 9 returns
     Reindeer 6 returns
     Reindeer 7 returns
     Reindeer 3 returns
     The last reindeer 8 wakes up Santa

Question 6.
I put the if stament for the reindeer frist, so 
if all reindeer are back he sees that frist.

Question 7.
I do this by locking the reindeer is a monitor 
that is signaled by santa after he is done with
the sleight and toys
ex.  The last reindeer 9 wakes up Santa
Santa is preparing sleighs
The team flies off (1)!

Question 8.
I do this by haveing the elfs locked in the 
monitor waithing for santa to let them in the 
door.
ex. The last reindeer 8 wakes up Santa
Santa answers the question posted by elves1, 2, 3
          Elf 1, 2, 3 return to work
          Elf 1 has a problem
          Elf 2 has a problem
          Elf 3 has a problem
          Elf 1, 2, 3 wake up the Santa
Santa is preparing sleighs
The team flies off (5)!


