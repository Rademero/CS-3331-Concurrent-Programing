#include "thread.h"
#include <iostream>
#include <functional>
#include <cstring>
#include<stdio.h>
int thread::swapped = true;
/* -----------------------------------------------------------*/
/* NAME : Michael Romero                    User ID: maromero */
/* DUE DATE : 3/17/2021                                       */
/* PROGRAM ASSIGNMENT # 3                                     */
/* FILE NAME : thread      									  */
/* PROGRAM PURPOSE :                                          */
/*    This program is the threads for comparison              */
/* -----------------------------------------------------------*/

/* ----------------------------------------------------------- */
/* FUNCTION  ThreadFunc                                            */
/*    thread setup with comparison                             */
/* PARAMETER USAGE :                                           */
/*		none                                                   */
/* FUNCTION CALLED :                                           */
/*    thread-main.sort 										   */
/* ----------------------------------------------------------- */
void thread::ThreadFunc()
{
	Thread::ThreadFunc(); // required
	char buf[100];
	sprintf(buf, "        Thread %d Created\n",thN);
	write(1, buf, strlen(buf));
	int temp;
	sprintf(buf, "        Thread %d compares x[%d -1] and x[%d]\n",thN,thN,thN);
	write(1, buf, strlen(buf));
	if (thX[thN - 1] > thX[thN]) {
		sprintf(buf, "        Thread %d swaps x[%d -1] and x[%d]\n", thN, thN, thN);
		write(1, buf, strlen(buf));
		temp = thX[thN - 1];
		thX[thN - 1] = thX[thN];
		thX[thN] = temp;
		swapped = true;
	}
	sprintf(buf, "        Thread %d exits\n", thN);
	write(1, buf, strlen(buf));
	Exit();
}/* ----------------------------------------------------------- */
/* FUNCTION  thread                                              */
/*     This method is used for comparison                      */
/* PARAMETER USAGE :                                           */
/*     x: pointer to an array
	   n: the position of the element to be checked            */
/* FUNCTION CALLED :                                           */
/*    thread-main.sort 										   */
/* ----------------------------------------------------------- */ thread::thread(int* x, int n) {
	thN = n;
	thX = x;}