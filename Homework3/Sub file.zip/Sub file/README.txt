Question 1. 
No, In my programe I have the algaritm sort
even the odd. Each thread runs concurenttly but
checks diffrent parts of the array.

Question 2.
my programe only runs n becuse my program sets 
swapped to false, each thread will set to true
only when a swapp has happend. My program will
compair evey part of the array with the items 
next to it. Now my program will only make n/2
threads based on the n inputs. Since a even and
odd pass will check half of the array with n/2
iterations, thus the program will only run n
times at most.

Question 3.
You could not have a program that does an even or
and odd pass at the same time becuse of a race 
condititon. This is becuse the if one swaps 
the value you could end up with a index in the
wrong part. This would happen if x[k-1] was 
smaller then x[k+1], the odd switches x[k] and
x[k+1], the the even switchs x[k+1] with x[k-1]
due to the race condition. 

Question 4.
Yes to this one becuse both would only check 
every other position. For a safer  result you
could set up a new array and have the odd fill in
the odd and the even fill in the even.